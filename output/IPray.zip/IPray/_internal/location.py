CityList = [['Surabaya','Semarang','Jakarta','Medan','Pontianak','Jayapura','Padang'],
            ['London','Liverpool','Oxford'],
            ['Berlin','Stuttgart','Dortmund']]
CountryList = ['Indonesia','United Kingdom','Germany']